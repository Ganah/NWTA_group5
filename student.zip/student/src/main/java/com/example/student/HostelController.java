package com.example.student;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import java.net.URL;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ResourceBundle;
import javafx.stage.Stage;

public class HostelController implements initializable{

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    }
    @FXML
    private TextField hostelTextField,locationTextField,studentsTextField,managerTextField;
    @FXML
    private Button hostelButton;
    @FXML
    private Label successLabel;

    public void registerHostel(){
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String hostel = hostelTextField.getText();
        String location= locationTextField.getText();
        String students= studentsTextField.getText();
        String manager= managerTextField.getText();

        String insertFields= "INSERT INTO hostel(hostel,location,students,manager) VALUES('";
        String insertValues= hostel+"','"+location+"','"+students+"','"+manager+"')";
        String insertToRegister= insertFields+insertValues;

        try{
            Statement statement = connectDB.createStatement();
            statement.executeUpdate(insertToRegister);
            successLabel.setText("Registration created successfully");
            createHostel();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    public void registerHostelOnAction(ActionEvent event) {
        registerHostel();
    }

    public void createHostel(){
        try{
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("personal.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 670, 426);
            Stage stage = new Stage();
            stage.setTitle("Hostel Registration Form");
            stage.setScene(scene);
            stage.show();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
}

package com.example.student;

import  javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ResourceBundle;

public class RegisterController implements initializable{
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    @FXML
    private Button closeButton;
    public void closeButtonOnAction(ActionEvent event){
        Stage stage=(Stage) closeButton.getScene().getWindow();
        stage.close();
        Platform.exit();
    }

    @FXML
    private Button registerButton;
    @FXML
    private Label successLabel;
    public void registerButtonOnAction(ActionEvent event){

        if(setPasswordField.getText().equals(confirmPasswordField.getText())) {
            registerUser();
        }
        else{
            wrongPasswordLabel.setText("Password does not match");
        }
    }

    @FXML
    private PasswordField setPasswordField,confirmPasswordField;
    @FXML
    private Label wrongPasswordLabel;
    @FXML
    private TextField firstnameTextField,lastnameTextField,usernameTextField;
    public void registerUser(){
       DatabaseConnection connectNow = new DatabaseConnection();
       Connection connectDB = connectNow.getConnection();

       String firstname = firstnameTextField.getText();
       String lastname= lastnameTextField.getText();
       String username= usernameTextField.getText();
       String password= setPasswordField.getText();

       String insertFields= "INSERT INTO user_account(firstname,lastname,username,password) VALUES('";
       String insertValues= firstname+"','"+lastname+"','"+username+"','"+password+"')";
       String insertToRegister= insertFields+insertValues;

       try{
           Statement statement = connectDB.createStatement();
           statement.executeUpdate(insertToRegister);
           successLabel.setText("Registration created successfully");
           createCourse();
       }
       catch(Exception e){
           e.printStackTrace();
           e.getCause();
       }
    }

    public void createCourse(){
        try{
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("home.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 681, 437);
            Stage stage = new Stage();
            stage.setTitle("Course Registration Form");
            stage.setScene(scene);
            stage.show();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
   }
//    @FXML
//    private ImageView brandingImageView;
//
//    @Override
//    public void initialize(URL url, ResourceBundle resourceBundle){
//        File brandingFile = new File("@p1.jpg");
//        Image brandingImage= new Image(brandingFile.toURI().toString());
//        brandingImageView.setImage(brandingImage);
//    }


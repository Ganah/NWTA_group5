package com.example.student;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ResourceBundle;

public class SkillController implements initializable{
    public void submitButtonOnAction(ActionEvent event) {
        registerSkill();
    }

    @FXML
    private TextField skillone,skilltwo,skillthree;

    @FXML
    private Button submitButton;

    @FXML
    private Label successLabel;

    public void registerSkill(){
        DatabaseConnection connectNow = new DatabaseConnection();
        Connection connectDB = connectNow.getConnection();

        String skilloneText = skillone.getText();
        String skilltwoText= skilltwo.getText();
        String skillthreeText= skillthree.getText();

        String insertFields= "INSERT INTO skill(firstskill,secondskill,thirdskill) VALUES('";
        String insertValues= skilloneText+"','"+skilltwoText+"','"+skillthreeText+"')";
        String insertToRegister= insertFields+insertValues;

        try{
            Statement statement = connectDB.createStatement();
            statement.executeUpdate(insertToRegister);
            successLabel.setText("Completed successfully");
           // createCourse();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }
}

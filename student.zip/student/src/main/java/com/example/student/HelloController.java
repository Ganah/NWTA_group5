package com.example.student;


import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;

import java.io.File;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

public class HelloController implements initializable{


//    @FXML
//    private Label welcomeText;


    @FXML
    private Button CancelButton;
    @FXML
    private Button loginButton;
    @FXML
    private Label loginMessageLabel;

    @FXML
    private TextField usernameTextField;

    @FXML
    private PasswordField enterPasswordField;

//    @FXML
//    private ImageView brandingImageView;
//
//    @Override
//    public void initialize(URL url, ResourceBundle resourceBundle){
//        File brandingFile = new File("@ktu.png");
//        Image brandingImage= new Image(brandingFile.toURI().toString());
//        brandingImageView.setImage(brandingImage);
//

    public void CancelButtonOnAction(ActionEvent event) {
        Stage stage=(Stage) CancelButton.getScene().getWindow();
        stage.close();
    }

    public void loginButtonOnClick(ActionEvent event){
      loginMessageLabel.setText("Wrong Logins");
      if(usernameTextField.getText().isBlank()==false && enterPasswordField.getText().isBlank()==false){
          validateLogin();
      }
      else{
           loginMessageLabel.setText("Please enter username and password");
      }
    }

    private void validateLogin() {
        DatabaseConnection connectNow= new DatabaseConnection();
        Connection connectDB=connectNow.getConnection();

        String verifyLogin= "SELECT count(1) FROM user_account WHERE username='" + usernameTextField.getText()+ "' AND password='" +enterPasswordField.getText()+ "'";

        try{
           Statement statement = connectDB.createStatement();
           ResultSet queryResult = statement.executeQuery(verifyLogin);

           while(queryResult.next()){
               if(queryResult.getInt(1)==1){
//                   loginMessageLabel.setText("Login Successful");
                   createAccountForm();
               }
               else{
                   loginMessageLabel.setText("Wrong Login, Retry");
               }
           }
        }
        catch (Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void createAccountForm(){
        try{
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("register.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 600, 400);
            Stage stage = new Stage();
            stage.setTitle("Student Registration Form");
            stage.setScene(scene);
            stage.show();
    }
        catch(Exception e){
           e.printStackTrace();
           e.getCause();
        }
    }
}
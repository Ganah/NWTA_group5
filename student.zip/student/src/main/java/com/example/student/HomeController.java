package com.example.student;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.net.URL;
import java.sql.Connection;
import java.sql.Statement;
import java.util.ResourceBundle;

public class HomeController implements initializable{
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

     @FXML
     private TextField course,level,section,session,firstcourse,secondcourse,thirdcourse;

     @FXML
     private Button submitButton;

     @FXML
     private Label successLabel;

     public void submitButtonOnAction(ActionEvent event){
         registerCourse();

     }
//linking to database
     public void registerCourse(){
         DatabaseConnection connectNow = new DatabaseConnection();
         Connection connectDB = connectNow.getConnection();

         String courseText= course.getText();
         String levelText = level.getText();
         String sectionText= section.getText();
         String sessionText= session.getText();
         String firstcourseText=firstcourse.getText();
         String secondcourseText=secondcourse.getText();
         String thirdcourseText=thirdcourse.getText();

         String insertFields= "INSERT INTO course(course,level,section,session,firstC,secondC,thirdC) VALUES('";
         String insertValues=courseText+"','"+levelText+"','"+sectionText+"','"+sessionText+"','"+firstcourseText+"','"+secondcourseText+"','"+thirdcourseText+"')";
         String insertToCourse= insertFields+insertValues;

         try{
             Statement statement = connectDB.createStatement();
             statement.executeUpdate(insertToCourse);
             successLabel.setText("Course Registered successfully");
             createHostel();
         }
         catch(Exception e){
             e.printStackTrace();
             e.getCause();
         }
     }

    public void createHostel(){
        try{
            FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hostel.fxml"));
            Scene scene = new Scene(fxmlLoader.load(), 627, 423);
            Stage stage = new Stage();
            stage.setTitle("Hostel Registration Form");
            stage.setScene(scene);
            stage.show();
        }
        catch(Exception e){
            e.printStackTrace();
            e.getCause();
        }
    }
}
